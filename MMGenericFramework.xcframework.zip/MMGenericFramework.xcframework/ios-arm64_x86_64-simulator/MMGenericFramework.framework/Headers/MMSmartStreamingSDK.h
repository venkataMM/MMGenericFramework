//
//  MMSmartStreamingVOPlayer.h
//  MMSmartStreamingVOPlayer
//
//  Created by Anurag on 14/1/19.
//  Copyright © 2019 MediaMelon. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MMSmartStreaming.
FOUNDATION_EXPORT double MMSmartStreamingVersionNumber;

//! Project version string for MMSmartStreaming.
FOUNDATION_EXPORT const unsigned char MMSmartStreamingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MMSmartStreaming/PublicHeader.h>
