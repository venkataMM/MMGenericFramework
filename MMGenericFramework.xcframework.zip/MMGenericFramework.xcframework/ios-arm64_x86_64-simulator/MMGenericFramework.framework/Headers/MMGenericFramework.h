//
//  MMGenericFramework.h
//  MMGenericFramework
//
//  Created by Anurag Singh on 11/10/21.
//

#import <Foundation/Foundation.h>

//! Project version number for MMGenericFramework.
FOUNDATION_EXPORT double MMGenericFrameworkVersionNumber;

//! Project version string for MMGenericFramework.
FOUNDATION_EXPORT const unsigned char MMGenericFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MMGenericFramework/PublicHeader.h>


#import "objc_mmsmartstreaming.h"
#import "MMSmartStreaming.h"
#import "MMSmartStreamingSDK.h"
